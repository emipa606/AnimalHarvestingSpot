﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using RimWorld;
using Verse;
using Verse.AI;


namespace AnimalHarvestingSpot
{
	public abstract class JobDriver_AnimalGatheringOnSpot : JobDriver_GatherAnimalBodyResources
	{
		public override bool TryMakePreToilReservations ()
		{
			//Log.Message("try to reserve!");
			List<Thing> list = new List<Thing> ();
			foreach (Building bld in pawn.Map.listerBuildings.AllBuildingsColonistOfDef(ThingDef.Named("AnimalHervestingSpot"))) {
				list.Add (bld as Thing);
			}
			Pawn target = TargetA.Thing as Pawn;
			spot = GenClosest.ClosestThing_Global_Reachable (
				target.Position, target.Map, list,
				PathEndMode.Touch, TraverseParms.For (target, Danger.Deadly, TraverseMode.ByPawn, false), 999f, null, null);

			//Log.Message("spot is "  + spot);
			if (spot != null && CanTarget (target)) {
				return pawn.Reserve (job.GetTarget (TargetIndex.A), job, 1, -1, null);
			}
			spot = null;
			return base.TryMakePreToilReservations ();
		}

		Thing spot = null;

		protected override IEnumerable<Toil> MakeNewToils ()
		{
			Toil CallVictim = new Toil () {
				initAction = () => {
					if (spot == null || spot.Destroyed) {
						//Log.Message ("curtoil=" + this.CurToil);
						this.ReadyForNextToil ();
					}
					Pawn target = TargetA.Thing as Pawn;
					//Log.Message("goto spot with" + target);
					pawn.pather.StartPath (spot.Position, PathEndMode.Touch);
					Job gotojob = new Job (JobDefOf.GotoWander, spot.Position);
					gotojob.locomotionUrgency = LocomotionUrgency.Sprint;
					target.jobs.StartJob (gotojob, JobCondition.InterruptOptional, null, true, false, null, JobTag.MiscWork, false);
				},
				defaultCompleteMode = ToilCompleteMode.PatherArrival
			};
			yield return CallVictim;

			Toil WaitVictim = new Toil () {
				defaultCompleteMode = ToilCompleteMode.Never,
				tickAction = () => {
					if (spot == null || spot.Destroyed) {
						//Log.Message ("curtoil=" + this.CurToil);
						this.ReadyForNextToil ();
					}
					if (Find.TickManager.TicksGame % 100 == 0) {
						Pawn target = TargetA.Thing as Pawn;
						//Log.Message("waiting target" + target);
						if (pawn.Position.DistanceToSquared (target.Position) < 32f) {
							Job waitjob = new Job (JobDefOf.Wait);
							target.jobs.StartJob (waitjob, JobCondition.InterruptForced, null, false, true, null, JobTag.MiscWork, false);
							this.ReadyForNextToil ();
						} else {
							target.jobs.EndCurrentJob (JobCondition.InterruptForced, false);
							Job gotojob = new Job (JobDefOf.GotoWander, spot.Position);
							gotojob.locomotionUrgency = LocomotionUrgency.Sprint;
							target.jobs.StartJob (gotojob, JobCondition.InterruptOptional, null, true, false, null, JobTag.MiscWork, false);
						}
					}
				}
			};
			yield return WaitVictim;
			Toil ReleaseVictim = new Toil () {
				defaultCompleteMode = ToilCompleteMode.Instant,
			};
			ReleaseVictim.AddFinishAction (() => {
				Pawn target = TargetA.Thing as Pawn;
				if (target != null) {
					target.ClearMind (true);
				}
			});
			yield return ReleaseVictim;
			foreach (Toil toil in base.MakeNewToils()) {
				yield return toil;
			}
		}

		protected virtual bool CanTarget (Pawn trg)
		{
			if (trg.GetStatValue (StatDefOf.MoveSpeed, true) <= this.pawn.GetStatValue (StatDefOf.MoveSpeed, true) / 2f) {
				return false;
			}
			return true;
		}
	}
}

